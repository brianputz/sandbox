package simpledb;

/** TransactionId is a class that contains the identifier of
    a transaction.  Currently unimplemented.
*/
public class TransactionId {
  static int counter = 0;

  int myid;
  public TransactionId() {
    myid = counter++;
  }
}
