package simpledb;

/** A RecordID is a reference to a specific tuple on a specific page of a specific
  table 
  */
public class RecordID {

  /** Constructor.
   * @param tableid the table that this record is in
   * @param pageno the page of tableid that this record is in
   * @param tupleno the tuple number within the page.
   */
  public RecordID(int tableid, int pageno, int tupleno) {
    // some code goes here
  }

  /**
   * @return the page this RecordId references.
   */
  public int pageno() {
    // some code goes here
    return 0;
  }

  /**
   * @return the tuple number this RecordId references.
   */
  public int tupleno() {
    // some code goes here
    return 0;
  }

  /**
   * @return the table id this RecordId references.
   */
  public int tableid() {
    // some code goes here
    return 0;
  }
}
