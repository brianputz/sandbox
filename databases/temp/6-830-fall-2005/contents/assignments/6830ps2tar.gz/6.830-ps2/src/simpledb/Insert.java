package simpledb;
import java.util.*;
import java.io.*;

/**
 * Inserts tuples read from the child operator into
 * the tableid specified in the constructor
 */
public class Insert implements DbIterator {

  /**
   * Constructor.
   * @param t The transaction running the insert.
   * @param child The child operator to read tuples to be inserted from.
   * @param tableid The table to insert tuples into.
   */
  public Insert(TransactionId t, DbIterator child, int tableid) throws DbException {
    // some code goes here
  }

  public TupleDesc getTupleDesc() {
    // some code goes here
    return null;
  }

  public void open() throws DbException, TransactionAbortedException {
    // some code goes here
  }

  public void close() {
    // some code goes here
  }

  public void rewind() throws DbException, TransactionAbortedException {
    // some code goes here
  }

  /**
   * DbIterator getNext method.
   * Inserts tuples read from child into the tableid specified by the
   * constructor.  Inserts should be passed through BufferPool.  An instances
   * of BufferPool is available via BufferPool.Instance().  Note that insert
   * DOES NOT need check to see if a particular tuple is a duplicate before
   * inserting it.
   *
   * @return A 1-field tuple containing the number of deleted records.
   * @see BufferPool#Instance
   * @see BufferPool#insertTuple
   * @throws NoSuchElementException When the child iterator has no more tuples.
   */
  public Tuple getNext() throws NoSuchElementException, TransactionAbortedException {
    // some code goes here
    return null;
  }
}
