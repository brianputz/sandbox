package simpledb;

import java.util.*;

/**
 * SeqScan is an implementation of a sequential scan access method that reads
 * each tuple of a table in no particular order (e.g., as they are laid out on
 * disk).
 */
public class SeqScan implements DbIterator {

  /** Constructor.
   * Creates a sequential scan over the specified table as a part of the
   * specified transaction.
   * @param tid The transaction this scan is running as a part of.
   * @param tableid the table to scan.
   */
  public SeqScan(TransactionId tid, int tableid) {
    // some code goes here
  }

  /**
   * Opens this sequential scan.
   * Needs to be called before getNext().
   */
  public void open() throws DbException, NoSuchElementException, TransactionAbortedException {
    // some code goes here
  }

  /**
   * Implementation of DbIterator.getTupleDesc method.
   */
  public TupleDesc getTupleDesc() {
    // some code goes here
    return null;
  }

  /**
   * Implementation of DbIterator.getNext method.
   * Return the next tuple in the scan.
   * @throws NoSuchElementException if the scan is complete. 
   */
  public Tuple getNext() throws NoSuchElementException, TransactionAbortedException {
    // some code goes here
    return null;
  }

  /**
   * Closes the sequential scan.
   */
  public void close() {
    // some code goes here
  }

  /**
   * Rewinds the sequential back to the first record.
   */
  public void rewind() throws DbException, NoSuchElementException, TransactionAbortedException {
    // some code goes here
  }

}
