package simpledb;

import java.util.*;

/**
 * The Aggregator operator that computes an aggregate (e.g., sum, avg, max,
 * min).  Note that we only support aggregates over a single column, grouped
 * by a single column.
 */
public class Aggregate implements DbIterator {

  /**
   * Constructor.
   * @param child The DbIterator that is spoonfeeding us tuples.
   * @param afield The column over which we are computing an aggregate.
   * @param gfield The column over which we are grouping the result.
   * @param agg The class that implements the aggregated value.
   */
  public Aggregate(DbIterator child, int afield, int gfield, Aggregator agg) {
    // some code goes here
  }

  public void open() throws NoSuchElementException, DbException, TransactionAbortedException {
    // some code goes here
  }

  /**
   * Returns the next tuple where the first field is the field by which we are
   * grouping, and the second field is the result of computing the aggregate.
   */
  public Tuple getNext() throws TransactionAbortedException {
    // some code goes here
    return null;
  }

  public void rewind() throws DbException, TransactionAbortedException {
    // some code goes here
  }

  /**
   * Returns the TupleDesc of this Aggregate.
   * This is always a 2-field tuple.
   */
  public TupleDesc getTupleDesc() {
    // some code goes here
    return null;
  }

  public void close() {
    // some code goes here
  }
}
