package simpledb;

/** Predicate compares tuples to a specified Field value.
*/
public class Predicate {

  /** Constant for EQUALS operation and return code from Field.compare */
  public static final int EQUALS = 0;  

  /** Constant for GREATER_THAN operation and return code from Field.compare */
  public static final int GREATER_THAN = 1;

  /** Constant for LESS_THAN operation and return code from Field.compare */
  public static final int LESS_THAN = 2;

  /** Constant for LESS_THAN_OR_EQ operation */
  public static final int LESS_THAN_OR_EQ = 3;

  /** Constant for GREATER_THAN_OR_EQ operation */
  public static final int GREATER_THAN_OR_EQ = 4;

  /** Constructor.
   * @param field field number of passed in tuples to compare against.
   * @param op operation to use for comparison
   * @param operand field value to compare passed in tuples to
   */
  public Predicate(int field, int op, Field operand) {
    // some code goes here
  }

  /**
   * Compares the field number of t specified in the constructor to the
   * operand field specified in the constructor using the operator specific in
   * the constructor.
   * @param t The tuple to compare against
   * @return true if the comparison is true, false otherwise.
   */
  public boolean filter(Tuple t) {
    // some code goes here
    return false;
  }
}
