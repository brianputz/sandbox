package simpledb;

import java.util.*;

/**
 * Knows how to compute some aggregate over a set of IntFields.
 */
public class IntAggregator implements Aggregator {

  public IntAggregator(int what) {
    // some code goes here
  }

  /**
   * Takes a list of IntFields and returns an aggregate.  The specific
   * aggregate we're computing depends on the first parameter to our
   * Constructor.
   */
  public Field execute(List list) {
    // some code goes here
    return null;
  }
}
