package simpledb;

import java.lang.Exception;

public class DeadlockException extends Exception {
  public DeadlockException() {
  }
}
