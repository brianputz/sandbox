package simpledb;

import java.io.*;
import java.util.*;
import java.text.ParseException;

/**
 * HeapFile is an implementation of a DbFile that stores a collection
 * of tuples in no particular order.  Tuples are stored on pages, each of which
 * is a fixed size, and the file is simply a collection of those pages.
 * HeapFile works closely with HeapPage.  The format of HeapPages is described
 * in the HeapPage constructor.
 *
 * @see simpledb.HeapPage#HeapPage
 * @author Sam Madden
 */
public class HeapFile implements DbFile {

  /**
   * Constructor.
   * Creates a new heap file with the specified tuple descriptor that stores
   * pages in the specified buffer pool.

   * @param f The file that stores the on-disk backing store for this DbFile.
   */
  public HeapFile(File f) {
    // some code goes here
  }

  /**
   */
  public int id() {
    // some code goes here
    return 0;
  }

  /**
   * Returns a Page from the file.
   */
  public Page readPage(PageId id) throws NoSuchElementException {
    // some code goes here
    return null;
  }

  /**
   * Writes the given page to the appropriate location in the file.
   */
  public void writePage(Page p) throws IOException {
    // some code goes here
  }

  /**
   * Returns the number of pages in this HeapFile.
   */
  public int numPages() {
    // some code goes here
    return 0;
  }

  /**
   * Adds the specified tuple to the table under the specified TransactionId.
   *
   * @throws DbException
   * @throws IOException
   */
  public Page addTuple(TransactionId tid, Tuple t) throws DbException, IOException, TransactionAbortedException {
    // some code goes here
    return null;
  }

  /**
   * Deletes the specified tuple from the table, under the specified
   * TransactionId.
   */
  public Page deleteTuple(TransactionId tid, Tuple t) throws DbException, TransactionAbortedException {
    // some code goes here
    return null;
  }

}
