package simpledb;

import simpledb.*;
import java.util.*;
import java.io.*;

/**
 * BufferPool manages the reading and writing of pages into memory from
 * disk.
 * Access methods call into it to retrieve pages, and it fetches pages from
 * the appropriate location.
 * <p>
 * The BufferPool is alos responsible for locking;  when a transaction fetches
 * a page, BufferPool which check that the transaction has the appropriate
 * locks to read/write the page.
 */
public class BufferPool {
  /** Bytes per page, excluding header. */
  public static final int PAGE_SIZE = 4096;  
  private static final int NUM_PAGES = 16;
  private static final BufferPool _instance = new BufferPool(NUM_PAGES);

  /**
   * Access to BufferPool instance.
   */
  public static BufferPool Instance() {
    return _instance;
  }

  /**
   * Constructor.
   * @param numPages number of pages in this buffer pool 
   */
  private BufferPool(int numPages) {
    // some code goes here
  }

  /**
   * Retrieve the specified page with the associated permissions.
   * Will acquire a lock and may block if that lock is held by another
   * transaction.
   */
  public Page getPage(TransactionId tid, PageId pid, Permissions perm) throws TransactionAbortedException {
    // some code goes here
    return null;
  }

  /**
   * Releases the lock on a page.
   * Calling this is very risky, and may result in wrong behavior. Think hard
   * about who needs to call this and why, and why they can run the risk of
   * calling it.
   */
  public void releasePage(TransactionId tid, PageId pid) {
    // some code goes here
  }

  /**
   * Release all locks associated with a given transaction.
   */
  public void transactionComplete(TransactionId tid) {
    // some code goes here
  }

  /**
   * Add a tuple to the specified table behalf of transaction tid.
   * Will acquire a write lock on the page the tuple is added to. May block if
   * the lock cannot be acquired.

   * @param tid the transaction adding the tuple
   * @param tableId the table to add the tuple to
   * @param t the tuple to add
   */
  public void insertTuple(TransactionId tid, int tableId, Tuple t)
    throws DbException, IOException, TransactionAbortedException
  {
    // some code goes here
  }

  /**
   * Remove the specified tuple from the buffer pool.
   * Will acquire a write lock on the page the tuple is added to. May block if
   * the lock cannot be acquired.

   * @param tid the transaction adding the tuple.
   * @param t the tuple to add
   */
  public void deleteTuple(TransactionId tid, Tuple t) throws DbException, TransactionAbortedException {
    // some code goes here
  }

  /**
   * Flush all dirty pages to disk.
   * NB: THIS IS PURELY FOR TESTING PURPOSES.  YOU SHOULD NOT NEED TO
   * CALL THIS FUNCTION AS IT WILL BREAK THE TRANSACTION SYSTEM IN SIMPLEDB.  
   * The only reason this exists is so that the tester
   * can force pages to disk.  
   */
  public void flush_all_pages() throws IOException {
    // some code goes here
  }

  /**
   * Flushes a certain page to disk
   */
  private void flush_page(PageId pid) throws IOException {
    // some code goes here
  }

}
