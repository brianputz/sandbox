import java.util.*;
import simpledb.*;
import simpledb.test.Test;
import java.io.*;

public class simpledb {

  public static void main (String args[]) {
    // convert a file
    if(args[0].equals("convert")) {
      try {
        PageEncoder.convert(new File(args[1]),
                            new File(args[1].replaceAll(".txt", ".dat")),
                            BufferPool.PAGE_SIZE,
                            Integer.parseInt(args[2]));
      } catch (IOException e) {
      }
      return;
    }

    Class c = null;
    try {
      c = Class.forName(args[0]);
    } catch(ClassNotFoundException e) {
      System.out.println("Couldn't find class " + args[0]);
    }

    Test t = null;
    try {
      t = (Test) c.newInstance();
    } catch(InstantiationException e) {
      System.out.println("Couldn't instantiate class " + args[0]);
    } catch(IllegalAccessException e) {
      System.out.println("Couldn't access class " + args[0]);
    }

    t.runTest(args);
  }
}
