package simpledb;

import java.util.*;

/**
 * TupleDesc describes the schema of a tuple.
 */
public class TupleDesc {
  /**
   * Merge two TupleDescs into one, with td1.numFields + td2.numFields fields,
   * with the first td1.numFields coming from td1 and the remaining from td2
   * @param td1 The TupleDesc with the first fields of the new TupleDesc
   * @param td2 The TupleDesc with the last fields of the TupleDesc
   * @return the new TupleDesc
   */
  public static TupleDesc combine(TupleDesc td1, TupleDesc td2) {
    // some code goes here
    return null;
  }

  /**
   * Constructor.
   * Create a new tuple desc with typeAr.length fields 
   * with fields of the specified types.
   * @param typeAr array specifying the number of and types of fields in this TupleDesc
   */
  public TupleDesc(Type[] typeAr) {
    // some code goes here
  }

  /**
   * @return the number of fields in this TupleDesc
   */
  public int numFields() {
    // some code goes here
    return 0;
  }

  /**
   * Gets the type of the ith field of this TupleDesc.
   * @param i The index of the field to get the type of
   * @return the type of the ith field
   * @throws NoSuchElementException if i is not a valid field reference.
   */
  public Type getType(int i) throws NoSuchElementException{
    // some code goes here
    return null;
  }

  /**
   * @return The size (in bytes) of tuples corresponding to this TupleDesc.
   * Note that tuples from a given TupleDesc are of a fixed size.
   */
  public int getSize() {
    // some code goes here
    return 0;
  }

  /**
   * Returns whether or not two TupleDesc are equal.
   * Two TupleDescs are considered equal if they are the same size and if the
   * n-th type in this TupleDesc is equal to the n-th type in td.
   */
  public boolean equals(TupleDesc td) {
    // some code goes here
    return false;
  }
}
