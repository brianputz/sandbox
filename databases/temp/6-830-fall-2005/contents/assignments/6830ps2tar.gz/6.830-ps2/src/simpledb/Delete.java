
package simpledb;
import java.util.*;
import java.io.*;

/** The delete operator.  Delete reads tuples
  from its child operator and removes them
  from the table they belong to.

*/

public class Delete implements DbIterator {

  /**
   * Constructor specifying the transaction that this delete belongs to as
   * well as the child to read from.
   * @param t The transaction this delete runs in
   * @param child The child operator to read tuples for deletion from
   */
  public Delete(TransactionId t, DbIterator child) {
    // some code goes here
  }

  public TupleDesc getTupleDesc() {
    // some code goes here
    return null;
  }

  public void open() throws DbException, TransactionAbortedException {
    // some code goes here
  }

  public void close() {
    // some code goes here
  }

  public void rewind() throws DbException, TransactionAbortedException {
    // some code goes here
  }

  /**
   * DbIterator getNext method.
   * Deletes tuples as they are read from the child operator. Deletes are
   * process via the buffer pool (which can be access via the
   * BufferPool.Instance() method.
   * @return A 1-field tuple containing the number of deleted records.
   * @see BufferPool#Instance
   * @see BufferPool#deleteTuple
   */
  public Tuple getNext() throws NoSuchElementException, TransactionAbortedException {
    // some code goes here
    return null;
  }
}
