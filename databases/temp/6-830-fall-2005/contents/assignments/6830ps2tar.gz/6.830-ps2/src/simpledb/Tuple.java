package simpledb;

/**
 * Tuple maintains information about the contents of a tuple.
 * Tuples have a specified schema specified by a TupleDesc object and contain
 * Field objects with the data for each field.
 */
public class Tuple {

  /**
   * Constructor.
   * Create a new tuple with the specified schema (type).
   * @param td The schema of this tuple.
   */
  public Tuple(TupleDesc td) {
    // some code goes here
  }

  /**
   * @return The TupleDesc representing the schema of this tuple.
   */
  public TupleDesc getTupleDesc() {
    // some code goes here
    return null;
  }

  /**
   * @return The RecordID representing the location of this this tuple on
   * disk.  May be null.
   */
  public RecordID getRecordID() {
    // some code goes here
    return null;
  }

  /**
   * @return Set the RecordID information for this tuple.
   * @param rid The new RecordID of this tuple.
   */
  public void setRecordID(RecordID rid) {
    // some code goes here
  }

  /**
   * Change the value of the ith field of this tuple.
   * @param i The index of the field to change
   * @param f The value to change it to.
   */
  public void setField(int i, Field f) {
    // some code goes here
  }

  /**
   * Return the value of the ith field.
   */
  public Field getField(int i) {
    // some code goes here
    return null;
  }

  /**
   * Dumps the contents of this Tuple on standard out.
   * Note that to pass the grader.pl script, the format needs to be as
   * follows:
   * column1\tcolumn2\tcolumn3\t...\tcolumnN
   * column1\tcolumn2\tcolumn3\t...\tcolumnN
   * column1\tcolumn2\tcolumn3\t...\tcolumnN
   *
   * where \t is any whitespace, except newline.
   */
  public void print() {
    // some code goes here
  }
}
