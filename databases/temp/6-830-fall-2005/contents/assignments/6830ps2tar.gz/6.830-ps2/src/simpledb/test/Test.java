package simpledb.test;

import simpledb.*;
import java.util.*;
import java.io.*;

public class Test {
  DbFile file[][];
  final static int MAX_COLUMNS = 128;
  final static int MAX_TABLES = 3;

  /*
   * Create all tables of up to 128 columns.
   * The table with 1 column is in a file called "f0.dat"
   * The table with 2 columns is in a file called "f1.dat"
   * ...
   */
  public Test() {
    file = new HeapFile[MAX_COLUMNS][MAX_TABLES];

    for(int i=0; i<MAX_COLUMNS; i++) {
      Type ta[] = new Type[i+1];
      for(int j=0; j<i+1; j++)
        ta[j] = Type.INT_TYPE;
      TupleDesc t = new TupleDesc(ta);
      for(int k=0; k<MAX_TABLES; k++) {
        file[i][k] = new HeapFile(new File("f" + i + "." + k + ".dat"));
        Catalog.Instance().addTable(file[i][k], t);
      }
    }
  }

  public void dump(TransactionId tid, DbIterator dbi) throws TransactionAbortedException {
    try {
      dbi.open();
    } catch (DbException e) {
    }

    try {
      while (true) {
        Tuple tup = dbi.getNext();
        tup.print();
      }
    } catch(NoSuchElementException e) {
      dbi.close();
    }
  }

  public void dump(TransactionId tid, DbFile file) throws TransactionAbortedException {
    SeqScan ss = new SeqScan(tid, file.id());
    dump(tid, ss);
  }

  public void dump(DbFile file) throws TransactionAbortedException {
    TransactionId tid = new TransactionId();				
    SeqScan ss = new SeqScan(tid, file.id());
    dump(tid, ss);
    BufferPool.Instance().transactionComplete(tid);
  }

  public boolean runTest(String args[]) {
    return false;
  }
}
