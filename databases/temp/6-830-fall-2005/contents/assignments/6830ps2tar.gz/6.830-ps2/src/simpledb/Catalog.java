package simpledb;

import java.util.*;

/**
 * The Catalog keeps track of all available tables in the database and their
 * associated schemas.
 * For now, this is a stub catalog that must be populated with tables by a
 * user program before it can be used -- eventually, this should be converted
 * to a catalog that reads a catalog table from disk.
 */

public class Catalog {

  private final static Catalog _instance = new Catalog();

  /**
   * Constructor.
   * Creates a new, empty catalog.
   */
  private Catalog() {
    // some code goes here
  }

  /**
   * Access to Catalog instance.
   */
  public static Catalog Instance() {
    return _instance;
  }

  /**
   * Add a new table to the catalog.
   * This table has tuples formatted using the specified TupleDesc and its
   * contents are stored in the specified DbFile. 
   * @param file the contents of the table to add
   * @param t the format of tuples that are being added
   */
  public void addTable(DbFile file, TupleDesc t) {
    // some code goes here
  }

  /**
   * Returns the tuple descriptor (schema) of the specified table
   */
  public TupleDesc getTupleDesc(int tableid) throws NoSuchElementException{
    // some code goes here
    return null;
  }

  /**
   * Returns the DbFile that can be used to read the contents of the specified table.
   */
  public DbFile getDbFile(int tableid) throws NoSuchElementException {
    // some code goes here
    return null;
  }
}
